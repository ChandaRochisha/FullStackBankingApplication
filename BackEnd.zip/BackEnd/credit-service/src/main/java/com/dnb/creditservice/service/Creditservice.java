package com.dnb.creditservice.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.dnb.creditservice.dto.Credit;
import com.dnb.creditservice.exceptions.IdNotFoundException;

@Service
public interface Creditservice {
	public Credit CreateCredit(Credit credit);
	public Iterable<Credit> getAllCredit();
	public List<Credit> getAllByUserId(Integer userId);
	public boolean checkCreditById(String loanId);

	public Optional<Credit> getCreditById(String loanId);
	public Credit changeCreditStatuts(String loanId) throws IdNotFoundException;
}
