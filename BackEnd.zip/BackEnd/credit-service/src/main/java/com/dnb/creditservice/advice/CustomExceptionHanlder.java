package com.dnb.creditservice.advice;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class CustomExceptionHanlder extends ResponseEntityExceptionHandler {
//@Override
//protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgument,) 
//
//handleMethodArgumentNotValid()

	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatusCode status, WebRequest request) {
		// TODO Auto-generated method stub
		Map<String,Object> responsBody = new HashMap<>();
		responsBody.put("timestamp", LocalDate.now());
		responsBody.put("status", status.value());
		
//		
//		List<String> errors = ex.getBindingResult().
//				getFieldErrors().
//				stream().
//				map(x -> x.getField())
//				.collect(Collectors.toList());
		
		List<String> errortype =  ex.getBindingResult().
				getFieldErrors().
				stream().
				map(x -> x.getDefaultMessage())
				.collect(Collectors.toList());
//		Map<String, String> map;
//		Set<String> set = new HashSet<>(errortype);
//
//		map = errors.stream()
//		           .filter(set::contains)
//		           .collect(Collectors.toMap(k -> k, v -> errortype.get(errortype.indexOf(v))));
//		responsBody.put("", map);
//		Stream<FieldError> errors = ex.getBindingResult().getFieldErrors().stream();
//
//			
//
//			Map<String,String> error = errors.collect(Collectors.toMap(a -> a.getField(), ex1->ex1.getDefaultMessage()));

			

		//	responsBody.put("errors", error);

		responsBody.put("errors", errortype);
		return new ResponseEntity<>(responsBody, headers, status);
	}
}
