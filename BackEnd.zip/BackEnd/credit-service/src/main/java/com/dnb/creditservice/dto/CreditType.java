package com.dnb.creditservice.dto;

public enum CreditType {
loan,creditCard
}
