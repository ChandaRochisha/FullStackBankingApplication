package com.dnb.creditservice.dto;

import lombok.Data;

@Data
public class User {

}
