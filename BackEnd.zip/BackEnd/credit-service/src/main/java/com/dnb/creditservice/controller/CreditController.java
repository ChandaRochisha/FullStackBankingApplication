package com.dnb.creditservice.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dnb.creditservice.dto.Credit;
import com.dnb.creditservice.exceptions.IdNotFoundException;
import com.dnb.creditservice.service.Creditservice;

@RestController
@RequestMapping("/api/credit")
public class CreditController {
	@Autowired
	Creditservice creditservice;
	
	@PostMapping("/create")
	public ResponseEntity<?> createCredit(@RequestBody Credit credit)
	{Credit credit1 = creditservice.CreateCredit(credit);
	return new ResponseEntity(credit1, HttpStatus.CREATED);

		
	}
	@GetMapping("/{loanId}")
	public ResponseEntity<?> getloadbyid(@PathVariable("loanId") String loanId) throws IdNotFoundException{
		Optional<Credit> optional = creditservice.getCreditById(loanId);
		if (optional.isPresent()) {
			
			return ResponseEntity.ok(optional);
		} else {
			throw new IdNotFoundException("Mentioned product id not found");
		}
	}
	

	
	@GetMapping("/allCredit")
	public ResponseEntity<?> getAllloans() {
		Iterable<Credit> optional = creditservice.getAllCredit();
		return ResponseEntity.ok(optional);
	}
}
