
package com.dnb.creditservice.advice;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import com.dnb.creditservice.exceptions.IdNotFoundException;

@ControllerAdvice
public class AppAdvice {

	
	@ResponseStatus(value = HttpStatus.NOT_FOUND,reason = "invalid id provided")
	@ExceptionHandler(IdNotFoundException.class)
	
public ResponseEntity<?>   invalidAccountIdExceptionHandler(IdNotFoundException e) {
		
		Map<String,String> mp=new HashMap<>();
		
		mp.put("message", e.getMessage());
		
		mp.put("HttpStatus", HttpStatus.NOT_FOUND+"");
		
		return new ResponseEntity(mp,HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(HttpRequestMethodNotSupportedException.class)
	public ResponseEntity<Map<String,String>> ExceptionHandler (HttpRequestMethodNotSupportedException e) throws IOException {
		
		String provided=e.getMethod();
		List<String> supported= List.of(e.getSupportedMethods());
		
		String error=provided
				+"is not one of the supported Http methods("+String.join(";", supported)+")";
		//"key",vale,"key",value
		Map<String, String> errorResponse=Map.of("error",error,"message",e.getLocalizedMessage(),"status",HttpStatus.METHOD_NOT_ALLOWED.toString());
		
		
		return new ResponseEntity<>(errorResponse,HttpStatus.METHOD_NOT_ALLOWED);
		
		
	}

	
}