package com.dnb.creditservice.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dnb.creditservice.dto.Credit;
import com.dnb.creditservice.exceptions.IdNotFoundException;
import com.dnb.creditservice.repo.CreditRepository;

@Service
public class CreditServiceImpl implements Creditservice{
	@Autowired
	CreditRepository creditRepository;

	@Override
	public Credit CreateCredit(Credit credit) {
		// TODO Auto-generated method stub
		return creditRepository.save(credit);
	}

	@Override
	public Iterable<Credit> getAllCredit() {
		// TODO Auto-generated method stub
		return creditRepository.findAll();
	}

	@Override
	public List<Credit> getAllByUserId(Integer userId) {
		// TODO Auto-generated method stub
		return creditRepository.findAllByUserId(userId);
	}

	@Override
	public boolean checkCreditById(String loanId) {
		// TODO Auto-generated method stub
		return creditRepository.existsById(loanId);
	}

	@Override
	public Optional<Credit> getCreditById(String loanId) {
		// TODO Auto-generated method stub
		return creditRepository.findById(loanId);
	}

	@Override
	public Credit changeCreditStatuts(String loanId) throws IdNotFoundException {
		// TODO Auto-generated method stub
		boolean bool= creditRepository.existsById(loanId);
		if (!bool)
			throw new IdNotFoundException("loan Id Not Found");
		Optional<Credit> optional = this.getCreditById(loanId);
		if (optional.isEmpty())
			throw new IdNotFoundException("loan Id not found");
		
		Credit credit2=optional.get();
		if(!credit2.isCreditapprovalStatus())
			credit2.setCreditapprovalStatus(true);
		return creditRepository.save(credit2);


	}



}
