package com.dnb.creditservice.dto;


import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Credit {
	@Id
	@GeneratedValue(strategy = GenerationType.UUID)
	String loanId;
	Integer userId;
	@Enumerated(EnumType.ORDINAL)
    private CreditType creditType;
	
	long creditlimit= 1000000 ;

	boolean creditapprovalStatus = true;

}
