package com.dnb.accountservice.dto;

import lombok.Data;

@Data
public class Amount {
	long amount;

}
