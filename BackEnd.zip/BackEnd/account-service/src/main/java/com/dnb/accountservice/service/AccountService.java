package com.dnb.accountservice.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.dnb.accountservice.dto.Account;
import com.dnb.accountservice.dto.Amount;
import com.dnb.accountservice.exceptions.AccountCloseException;
import com.dnb.accountservice.exceptions.IdNotFoundException;
import com.dnb.accountservice.exceptions.InsufficientBalanceException;

@Service
public interface AccountService {
	public Account createAccount(Account account);
	
	public Optional<Account> getAccountByaccountId(String accountId);
	
	public Iterable<Account> getAllaccounts();
	
	public void deletaccountByaccountId(String accountId);
	
	boolean checkAcccountByaccountId(String accountId);
	public Optional<Account> getaccountByuserID(Integer userId);
	
	public Account depositAmount(String accountId, long balance) throws IdNotFoundException;
	public Account WithdrawAccount(String accountId, long balance) throws IdNotFoundException, InsufficientBalanceException;
	
	public Account closeAccount(String accountId) throws IdNotFoundException, AccountCloseException;
}
