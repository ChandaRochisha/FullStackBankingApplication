package com.dnb.accountservice.mapper;

import org.springframework.stereotype.Component;

import com.dnb.accountservice.dto.Account;
import com.dnb.accountservice.dto.Amount;
import com.dnb.accountservice.payload.request.AccountRequest;

@Component
public class RequestToEntity {
	public Account getaccountEntityRequest(AccountRequest accountrequest) {
		Account account = new Account();
		account.setAccountStatus(accountrequest.getAccountStatus());
		account.setPanNumber(accountrequest.getPanNumber());
		account.setAadharCardNumber(accountrequest.getAadharCardNumber());
		account.setAccountType(accountrequest.getAccountType());
		account.setUserId(accountrequest.getUserId());
		
		account.setBalance(accountrequest.getBalance());
		account.setContactNumber(accountrequest.getContactNumber());
		return account;
	}


}
