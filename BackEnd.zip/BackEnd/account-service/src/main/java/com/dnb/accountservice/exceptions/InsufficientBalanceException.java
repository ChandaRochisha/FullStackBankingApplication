package com.dnb.accountservice.exceptions;

public class InsufficientBalanceException extends Exception {
	public InsufficientBalanceException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
	@Override
		public String toString() {
			// TODO Auto-generated method stub
			return this.getMessage();
		}
}
