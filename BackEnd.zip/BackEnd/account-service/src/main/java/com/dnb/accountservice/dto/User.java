package com.dnb.accountservice.dto;

public class User {
private Integer userId;
	
	private String userName;
	private String emailId;
	private String password;

}
