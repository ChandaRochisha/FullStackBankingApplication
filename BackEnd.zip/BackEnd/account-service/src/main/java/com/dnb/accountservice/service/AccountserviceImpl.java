package com.dnb.accountservice.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.dnb.accountservice.dto.Account;
import com.dnb.accountservice.dto.Amount;
import com.dnb.accountservice.dto.User;
import com.dnb.accountservice.exceptions.AccountCloseException;
import com.dnb.accountservice.exceptions.IdNotFoundException;
import com.dnb.accountservice.exceptions.InsufficientBalanceException;
import com.dnb.accountservice.repo.AcountRepository;
import org.springframework.beans.factory.annotation.Value;

@Service
public class AccountserviceImpl implements AccountService {
	@Autowired
	AcountRepository accountrepository;
	@Autowired
	RestTemplate restTemplate;
	@Value("${api.auth}")
	String authUrl;

	@Override
	public Account createAccount(Account account) {
		ResponseEntity<User> responseEntity= restTemplate.getForEntity(authUrl+"/"+account.getUserId(), User.class);

		return accountrepository.save(account);
	}

	@Override
	public Optional<Account> getAccountByaccountId(String accountId) {

		return accountrepository.findById(accountId);
	}

	@Override
	public Iterable<Account> getAllaccounts() {

		return accountrepository.findAll();
	}

	@Override
	public void deletaccountByaccountId(String accountId) {

		accountrepository.deleteById(accountId);

	}

	@Override
	public boolean checkAcccountByaccountId(String accountId) {

		if (accountrepository.existsById(accountId))
			return true;
		else
			return false;
	}

	@Override
	public Optional<Account> getaccountByuserID(Integer userId) {

		return accountrepository.findByUserId(userId);
	}

	@Override
	public Account depositAmount(String accountId, long balance) throws IdNotFoundException {
		Optional<Account> account = this.getAccountByaccountId(accountId);
		if (account.isEmpty())
			throw new IdNotFoundException("Account Id Not found");
		Account retreivedAccount = account.get();
		long accountBalance = retreivedAccount.getBalance();
		retreivedAccount.setBalance(accountBalance + balance);
		return accountrepository.save(retreivedAccount);
	}

	@Override
	public Account WithdrawAccount(String accountId, long balance) throws IdNotFoundException, InsufficientBalanceException {
		Optional<Account> account = this.getAccountByaccountId(accountId);
		if (account.isEmpty())
			throw new IdNotFoundException("Account Id Not found");
		Account retreivedAccount = account.get();
		long accountBalance = retreivedAccount.getBalance();
		if((accountBalance - balance)<10000)
			throw new InsufficientBalanceException("You balance is suufficient");
		else
			retreivedAccount.setBalance(accountBalance - balance);
		return accountrepository.save(retreivedAccount);
	}

	@Override
	public Account closeAccount(String accountId) throws IdNotFoundException, AccountCloseException {

		boolean bool = accountrepository.existsById(accountId);
		if (!bool)
			throw new IdNotFoundException("Account Id Not Found");
		
		Optional<Account> account = this.getAccountByaccountId(accountId);
		if (account.isEmpty())
			throw new IdNotFoundException("Account Id not found");

		Account account2 = account.get();
		if (!account2.isAccountStatus())
			throw new AccountCloseException("Provided Account is already closed");
		account2.setAccountStatus(false);
		return accountrepository.save(account2);
	}

}
