package com.dnb.accountservice.payload.request;

import lombok.Data;

@Data
public class AmountRequest {
	long amount;

}
