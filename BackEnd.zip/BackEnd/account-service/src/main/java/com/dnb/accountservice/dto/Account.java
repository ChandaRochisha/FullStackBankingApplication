package com.dnb.accountservice.dto;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Account {
	@Id
	@GeneratedValue(strategy = GenerationType.UUID)
	String accountId;
	@Enumerated(EnumType.ORDINAL)
    private AccountType accountType;
	String panNumber;
	String aadharCardNumber;
	String contactNumber;
    boolean accountStatus= true;
    Integer userId;
    long balance;

}
