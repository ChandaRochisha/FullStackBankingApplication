package com.dnb.accountservice.payload.request;

import com.dnb.accountservice.dto.AccountType;

import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class AccountRequest {
	
	@Enumerated(EnumType.ORDINAL)
    private AccountType accountType;

	String panNumber;
	String aadharCardNumber;
	String contactNumber;
    Boolean accountStatus;
    Integer userId;
    long balance;
}
