package com.dnb.accountservice.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dnb.accountservice.dto.Account;
import com.dnb.accountservice.dto.Amount;
import com.dnb.accountservice.exceptions.AccountCloseException;
import com.dnb.accountservice.exceptions.IdNotFoundException;
import com.dnb.accountservice.payload.request.AmountRequest;
import com.dnb.accountservice.service.AccountService;

import jakarta.validation.Valid;
import jakarta.ws.rs.GET;


@RestController
@RequestMapping("/api/account")
public class AccountController {
	@Autowired
	AccountService accountService;
	@PostMapping("/create")
	public ResponseEntity<?> createAccount(@Valid @RequestBody Account account){
		
			Account account1 = accountService.createAccount(account);
			return new ResponseEntity(account1, HttpStatus.CREATED);
	
	}
	
	@GetMapping("/{accountId}")
	public ResponseEntity<?> getaccountById(@PathVariable("accountId") String accountId) throws IdNotFoundException{
		Optional<Account> optional = accountService.getAccountByaccountId(accountId);
		if(optional.isPresent()) {
			return ResponseEntity.ok(optional);
	}
		else {
			throw new IdNotFoundException("mentioned accountId not found");
		}
	}
	
	@GetMapping("/allaccounts")
	public ResponseEntity<?> getAllAccounts() {
		Iterable<Account> optional = accountService.getAllaccounts();
		
		return ResponseEntity.ok(optional);
	}
	
	
	@DeleteMapping("/{accountId}")
	public ResponseEntity<?> deleteaccounttById(@PathVariable("accountId") String accountId)
			throws IdNotFoundException {

		if (accountService.checkAcccountByaccountId(accountId)) {
			accountService.deletaccountByaccountId(accountId);
			return ResponseEntity.noContent().build();

		}
		if (accountService.checkAcccountByaccountId(accountId)) {
			System.out.println("Deletion not implemented properly, please delete again");
		} else
			throw new IdNotFoundException(" Id not found");
		return null;

	}
	
	@PutMapping("/deposit/{accountId}")
		public ResponseEntity<?> deposit(@PathVariable("accountId") String accountId, @RequestBody AmountRequest amountrequest) throws IdNotFoundException {
	
			Account account = accountService.depositAmount(accountId, amountrequest.getAmount());
			return ResponseEntity.ok(HttpStatus.ACCEPTED);
	
		
		}
	@PutMapping("/withdraw/{accountId}")
	public ResponseEntity<?> withdraw(@PathVariable("accountId") String accountId, @RequestBody AmountRequest amountrequest) throws IdNotFoundException {
		try {
			Account account = accountService.WithdrawAccount(accountId, amountrequest.getAmount());
			return new ResponseEntity(account, HttpStatus.ACCEPTED);
		}catch (Exception e) {
			return ResponseEntity.badRequest().body(e.getMessage());
		}

		}
	@GetMapping("/user/{userId}")

	public ResponseEntity<?>getAccountByUserId(@PathVariable("userId")Integer userId) throws IdNotFoundException{
		Optional<Account> optional=accountService.getaccountByuserID(userId);
		if(optional.isPresent()) {
			return ResponseEntity.ok(optional.get());
		}
		else {
			throw new IdNotFoundException("Id is not valid");
		}

	}
	@PostMapping("/close/{accountId}")
	public ResponseEntity<?> closeAccount(@PathVariable("accountId") String accountId) throws IdNotFoundException, AccountCloseException{
		Account account = accountService.closeAccount(accountId);
		if(account!=null) {
			return ResponseEntity.ok(account);
		}
		else {
			throw new IdNotFoundException("Id is not valid");
		}
	}
	
	

}
