package com.dnb.accountservice.exceptions;

public class AccountCloseException extends Exception {
	public AccountCloseException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
	@Override
		public String toString() {
			// TODO Auto-generated method stub
			return this.getMessage();
		}
}
