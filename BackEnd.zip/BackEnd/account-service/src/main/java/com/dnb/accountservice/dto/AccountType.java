package com.dnb.accountservice.dto;

public enum AccountType {
	SAVING_ACCOUNT, CURRENT_ACCOUNT

}
