package com.dnb.apigatewayservice.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.reactive.EnableWebFluxSecurity;
import org.springframework.security.config.web.server.ServerHttpSecurity;
import org.springframework.security.web.server.SecurityWebFilterChain;

@Configuration
@EnableWebFluxSecurity

public class SecurityConfig 
{
	//It allows configuring web based security for specific http requests. Bydefault it will be applied to all requests	
	@Bean
	public SecurityWebFilterChain springSecurityFilterChain(ServerHttpSecurity serverHttpSecurity) {
		//csrf cross site request forgery(used by hackers)
   serverHttpSecurity.cors().and().csrf().disable()
        .authorizeExchange(exchange -> exchange
                .anyExchange()
                .permitAll());
return serverHttpSecurity.build();
	}
}
