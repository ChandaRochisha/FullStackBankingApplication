import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Iaccount } from '../models/iaccount';
const headerData = {
  headers: { 'Content-Type': 'application/json' },
};
@Injectable({
  providedIn: 'root'
})
export class AccountService {

  constructor(private httpClient: HttpClient, private router: Router) {}
  endPoint: string = '/api/account';
  
  CreateAccount(account: Iaccount): Observable<any> {
    return this.httpClient.post(
      this.endPoint + '/create',
      account,
      headerData
    );
  }
  getAccountbyUserId(userId: string): Observable<any>{
    return this.httpClient.get(this.endPoint+'/user/'+userId);
  }
   deposit(accountId : String, amount: any):Observable<any> {
    return this.httpClient.put(this.endPoint+'/deposit/'+ accountId, {amount: amount}, headerData);
   }
   withdraw(accountId : String, amount: any): Observable<any>{
    return this.httpClient.put(this.endPoint+'/withdraw/'+ accountId, {amount: amount}, headerData);
   }
   closeAccount(accountId : String): Observable<any>{
    return this.httpClient.put(this.endPoint+'/close/'+accountId,{},headerData);
   }
   

}
