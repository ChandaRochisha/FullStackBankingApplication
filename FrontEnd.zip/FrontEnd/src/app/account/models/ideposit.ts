export interface Ideposit {
    "amount": number;
}
