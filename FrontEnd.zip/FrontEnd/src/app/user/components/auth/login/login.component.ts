import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Ilogin } from 'src/app/user/models/ilogin';
import { UserService } from 'src/app/user/services/user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  login: Ilogin = { username: '', password: '' };

loginSubmit() {
  console.log(this.login);
  this.userService.loginUser(this.login).subscribe(
    (res) => {
      console.log(JSON.stringify(res));
      localStorage.setItem('userDetails', JSON.stringify(res));
      localStorage.setItem('token', res.token);
      this.router.navigate(['/dashboard']);
    },
    (err) => console.log(err)
  );

}

constructor(private userService: UserService, private router: Router) {}

  ngOnInit(): void {
}

}
